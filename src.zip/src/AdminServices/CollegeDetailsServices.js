import axios from 'axios';

const COLLEGE_API_BASE_URL = "http://localhost:8080/api/collegeDetails/";

class CollegeDetailsServices{

    getCollegeDetails(){
        return axios.get(COLLEGE_API_BASE_URL+'get_college_details');
    }

   getDetailsById(id){
        return axios.get(COLLEGE_API_BASE_URL+'update_college_details/'+ id);
    }

    updateDetails(details, id){
        return axios.patch(COLLEGE_API_BASE_URL+'update_college_details/'+id, details);
    }

}

export default new CollegeDetailsServices()