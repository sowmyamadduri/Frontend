import axios from 'axios';

const ADMIN_API_BASE_URL = "http://localhost:8080/api/v1/updateuser/{id}";

const ADMIN_BASE_URL = "http://localhost:8080/resume";


class AdminService {

    AdminLogin(admin){
      return axios.post('http://localhost:8080/changepassword/registeruser',admin);
      
    }
    forgotPassword(ID){
        return axios.put("http://localhost:8080/api/v1/updateuser/"+ID);
    }
    

}

export default new AdminService();