import axios from 'axios';

const RECRUITER_API_BASE_URL = "http://localhost:8080/api/viewRecruiters/get_recruiter_list";

class RecruiterService {

    getRecruiter(){
        return axios.get(RECRUITER_API_BASE_URL);
    }
/*
    getRecruiterById(id){
        return axios.get(RECRUITER_API_BASE_URL + '/' + id);
    }
*/
    deleteRecruiter(id){
        return axios.delete(RECRUITER_API_BASE_URL + '/' + id);
    }
}

export default new RecruiterService()