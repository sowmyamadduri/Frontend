import Background from '../Adminimages/adminPic.png'
import React, { Component } from 'react'

class AdminNavigation extends Component {
    constructor(props) {
        super(props)

        this.state = {
              
        }
    }

    viewCol=(e)=>{
        this.props.history.push('/view_college_details');
    }

    viewRec=(e)=>{
        this.props.history.push('/get_recruiter_list');
    }

    render() {
        return (
            <div style={{ backgroundImage: `url(${Background})`, backgroundRepeat:"no-repeat", 
            backgroundSize:"cover", height:"100px", position: "absolute",
            left: "0",
            top: "7.6%",
    width: "1366px"}}>
                <br/><br/><br/><br/><br/><br/><br/>

            <a  className="text-dark"id="a" href="" onClick={this.viewCol}>View College Details</a> <br/>
            <a id="a"  className="text-dark"href="" onClick={this.viewRec}>View Recruiter's Details</a> <br/>
            <a id="a"  className="text-dark"href="" onClick={this.viewRec}>Delete Recruiter</a><br/>
            <a id="a"  className="text-dark"href="" >View Student's Details</a> <br/>
            
        
            </div>
        )
    }
}
export default AdminNavigation