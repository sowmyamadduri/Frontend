import React from 'react'
import { BrowserRouter as Router ,Switch , Route ,Link } from 'react-router-dom'

function HeaderComponent() {
    return (
 
        <div>
            <link rel="stylesheet" href="AddingCss.css"></link>
           <header id="head" className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">TRAINING AND PLACEMENT</a>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                            <Link className="nav-link " aria-current="page" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                            <Link className="nav-link" to="/about">About</Link>
                            </li>
                            {/* <li className="nav-item">
                            <Link className="nav-link" to="/signup">Register</Link>
                            </li> */}
                            {/*<li className="nav-item">
                            <Link className="nav-link" to="/login">Recruiter Login</Link>
                            </li>
                            <li className="nav-item">
                            <Link className="nav-link" to="/viewStudents">View Students</Link>
                            </li>*/}
                        </ul>
                    </div>
                    <a id="logout" href="" >Logout</a>
                   
            </div>
            </header>
        </div>

    
    );
}

export default HeaderComponent
{/*import React from 'react'

function HeaderComponent() {
    return (
        <div>
          
          <nav className="navbar navbar-expand-lg navbar-dark bg-info">
  {/*<div className="cotainer-fluid" >
  <header className="header">
    <span className="text-right">
    <a className="navbar-brand" href="#">Training and Placement Cell</a>
    <a className="navbar-brand" href="https:home.com" target="blank_space">Home</a>
    <a className="navbar-brand" href="https:contact.com" target="blank_space">ContactUs</a>
    
    {/*<button className="navbar-toggler" type="button" data-bs-toggle="collapse" 
    data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    </span>
    </header>
    {/*<div className="collapse navbar-collapse" id="navbarNav">
      <ul className="navbar-nav">
      
        {/* <li className="nav-item">
          <a className="nav-link" href="/login">Login</a>
        </li>
         
        
      </ul>
    </div>
    
  {/*</div>
  
</nav>

        </div>
    )
}

export default HeaderComponent
*/}