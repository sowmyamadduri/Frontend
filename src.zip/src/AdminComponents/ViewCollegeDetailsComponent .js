import React, { Component } from 'react'
import CollegeDetailsService from '../AdminServices/CollegeDetailsServices'
import Background from '../Adminimages/UniversityCampus7.jpg'

class ViewCollegeDetailsComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                collegeDetails: []
        }
        this.editDetails = this.editDetails.bind(this);
    }

    home=(e)=>{
        this.props.history.push('/admin_navigation');
    }

    editDetails(id){
        this.props.history.push(`/update_college_details/${id}`);
    }

    componentDidMount(){
        CollegeDetailsService.getCollegeDetails().then((res) => {
            this.setState({ collegeDetails: res.data});
        });
    }

    render() {
        return (
            <div style={{ backgroundImage: `url(${Background})`, backgroundRepeat:"no-repeat", 
                backgroundSize:"cover", height:"600px", position: "absolute",
                left: "0",
                top: "7.6%",
        width: "1366px"}}>

<a id="anchor" href="" onClick={this.home}>Click here to go back</a> 
                        
                
            <div
                class="p-5 text-center bg-image"
                style={{
                backgroundImage: "url('..images/UniversityCampus7.jpg)",
                height: "600px", backgroundRepeat:"no-repeat"
                }}>
             
                <div >
                <div className="container"><br/>
                <div className="row">
                    <div className="card col-md-6 offset-md-3"><br/>
                 <h2 className="text-center">College Details</h2>
                    <hr></hr>
                 
                 <div className="card-body">
                 <div className="text-left">
                        <table>
                                <tr>
                                    <td>College Name:</td>
                                    { this.state.collegeDetails.map(
                                        details => 
				                    <td key = {details.id}>{details.cname}</td>)}
                                </tr><br/>
                                <tr>
                                    <td>Address: </td>
				                    { this.state.collegeDetails.map(
                                        details => 
                                    <td key = {details.id}>{details.address}</td>)}
                                </tr><br/>
                                <tr>
                                    <td>Pin code: </td>
				                    { this.state.collegeDetails.map(
                                        details => 
                                    <td key = {details.id}>{details.pin}</td>)}
                                </tr><br/>
                                <tr>
                                    <td>Contact Number: </td>
				                    { this.state.collegeDetails.map(
                                        details => 
                                    <td key = {details.id}>{details.ccontactNo}</td>)}
                                </tr><br/>
                                <tr>
                                    <td>Email ID: </td>
                                    { this.state.collegeDetails.map(
                                        details => 
				                    <td key = {details.id}>{details.cemailId}</td>)}
                                </tr><br/>
			            </table>
                        </div>
                            {/*    {
                                    this.state.collegeDetails.map(
                                    details => 
                                        <div key = {details.cid}>
                                                 <button onClick={ () => this.editDetails(details.cid)} 
                                                 className="btn btn-primary">Update Details</button>
                                        </div>
                                    )
                                }
                            */}
                                
                    </div>
                    </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
        )
    }
}

export default ViewCollegeDetailsComponent