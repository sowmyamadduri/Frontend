import React, { Component } from 'react'
import RecruiterService from '../AdminServices/RecruiterService'
import Background from '../Adminimages/Interview.jpg'

class ViewRecruitersComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            recruiter: []
        }
        
        this.deleteRecruiter = this.deleteRecruiter.bind(this);
    }

    home=(e)=>{
        this.props.history.push('/admin_navigation');
    }

    deleteRecruiter(id){
        RecruiterService.deleteRecruiter(id).then( res => {
            this.setState({recruiter: this.state.recruiter.filter(recruiter => recruiter.id !== id)});
        });
    }
    /*
    viewRecruiterById(id){
        this.props.history.push(`/view_recruiter/${id}`);
    } */
    
    componentDidMount(){
        RecruiterService.getRecruiter().then((res) => {
            this.setState({ recruiter: res.data});
        });
    }

    render() {
        return (
            <div style={{ backgroundImage: `url(${Background})`, backgroundRepeat:"no-repeat",
            backgroundSize:"cover", height:"600px", position: "absolute",
                left: "0",
                top: "7.6%",
                width: "1366px"}}>
               
                <a id="col" href="" onClick={this.home}>Click here to go back</a> 
                       
                    <div
                class="p-5 text-center bg-image"
                style={{
                backgroundImage: "url('..images/Interview.jpg)",
                height: "600px", backgroundRepeat:"no-repeat"
                }}>

                <link rel="stylesheet" href="AddingCss.css"></link>
                 <h2 className="text-center">Recruiters List</h2>
                 
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th>Company</th>
                                    <th>Job Profile</th>
                                    <th>Eligibility Criteria</th>
                                    <th>Annual Package</th>
                                    <th>Department</th>
                                    <th>Email Id</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody id="body">
                                {
                                    this.state.recruiter.map(
                                        recruiter => 
                                        <tr key = {recruiter.id}>
                                             <td> { recruiter.company} </td>
                                             <td> { recruiter.jobProfile} </td>   
                                             <td> {recruiter.eligibilityCriteria}</td>
                                             <td>{recruiter.annualPackage}</td>
                                             <td>{recruiter.department}</td>
                                             <td> {recruiter.mail}</td>
                                             <td>
                                                 
                                                 <button style={{marginLeft: "10px"}} 
                                                 onClick={ () => this.deleteRecruiter(recruiter.id)} 
                                                 className="btn btn-danger">Delete </button>
                                                {/* <button style={{marginLeft: "10px"}} onClick={ () => this.viewEmployee(recruiter.id)} className="btn btn-info">View </button>*/}
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>
                 </div>
            </div>
        )
    }
}

export default ViewRecruitersComponent