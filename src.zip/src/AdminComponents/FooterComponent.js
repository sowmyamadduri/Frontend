import React, { Component } from 'react'

class FooterComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
               
                    <link rel="stylesheet" href="AddingCss.css"></link>
               
            <footer className="footer text-center col-sm-12">
            <spam className="text-muted">All Rights Reserved 2021 @Capgemini</spam></footer>
            
        </div>
        )
    }
}

export default FooterComponent