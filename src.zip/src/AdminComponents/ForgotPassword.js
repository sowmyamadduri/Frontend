import React,{ Component } from 'react'
import AdminService from '../AdminServices/AdminService';
class ForgotPassword extends Component{
    constructor(props) {
        super(props)

        this.state = {
           
            id: '',
            username: '',
            password: ''
        }
        this.changeIdHandler = this.changeIdHandler.bind(this);
        this.changeUsernameHandler = this.changeUsernameHandler.bind(this);
        this.changePasswordHandler = this.changePasswordHandler.bind(this);
        this.forgotPassword=this.forgotPassword.bind(this);
    }
    componentDidMount(){
        let admin= {id: this.state.id, username: this.state.username, password: this.state.password};
            AdminService.forgotPassword(admin).then((res) =>{
                let ad = res.data;
                this.setState({id: ad.id,
                    username: ad.username,
                    password : ad.password
                });
            });
        } 
         
         
        forgotPassword = (e) => {
            e.preventDefault();
            let admin= {id: this.state.id, username: this.state.username, password: this.state.password};
            AdminService.forgotPassword(admin).then(res =>{ this.props.history.push('/admin')
            });
        }
    changeIdHandler= (event) => {
        this.setState({id: event.target.value});
    }

    changeUsernameHandler= (event) => {
        this.setState({username: event.target.value});
    }

   
    changePasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }
   
    
    render() {
        return (
            <div class="pa-img">
            
            
               <div >
                <p class=" h3 text-center text-light bg-dark">Forgot Password</p>
                <br></br><br></br>
                   <div className = "container bg-info w-50">
                        <div >
                            <br></br>
                            <div className = "card ">
                                <div className = "card-body">
                                    <form>
                                    <div className = "form-group">
                                            <label className="float-left">  ID </label>
                                            <input placeholder="Enter your id" name="id" className="form-control" 
                                                value={this.state.id} onChange={this.changeIdHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label className="float-left"> UserName </label>
                                            <input placeholder="Enter your username" name="username" className="form-control" 
                                                value={this.state.username} onChange={this.changeUsernameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label className="float-left"> New Password </label>
                                            <input placeholder="Enter your new password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changePasswordHandler}/>
                                        </div>
                                        

                                        <button className="btn btn-dark text-center" onClick={this.forgotPassword}>Submit</button>
                                    </form>
                                   
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
            </div>
        )
    }

}
export default ForgotPassword