
import React from 'react';

import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import HeaderComponent from './HeaderComponent';
import ForgotPassword from './ForgotPassword';
import LoginComponent from './LoginComponent';



 


function AdminLogin() {
    return (
        <div>
            <Router> 
            
                   
                        <Switch>
                              
                              <Route path = "/admin" exact component = {HeaderComponent}></Route>
                              <Route path = "/forgotpassword" exact component = {ForgotPassword}></Route> 
                              <Route path="/adminlogin" exact component={AdminLogin}></Route> 
                              <Route path="/login" exact component={LoginComponent}></Route>
                              {/*<Route path = "/logout" exact component = {Logout}></Route>  
                              
                              
                               <Route path = "/admin/userslist" exact component = {ListOfUsers}></Route> 
    <Route path = "/admin/allfreshers" exact component = {ListOfFreshers}></Route> */}
                               
                               {/* <Route path = "/homepage" exact component = {MainHeaderComponent}></Route>  */}
                               
                        </Switch>
    
                    
                    {/* <CarouselMain/> */}
                  {/* <FooterComponent /> */}
            </Router>
        </div>
        
      );
}
export default AdminLogin