import React,{Component} from 'react'
import CollegeDetailsService from '../AdminServices/CollegeDetailsServices'

class UpdateCollegeDetailsComponent extends Component{
    constructor(props){
    super(props)

    this.state = {
        cid:this.props.match.params.cid,
        ccontactNo:'',
        cemailId:''
    }

    this.changeContactNoHandler=this.changeContactNoHandler.bind(this);
    this.changeEmailIdHandler=this.changeEmailIdHandler.bind(this);
    this.updateDetails=this.updateDetails.bind(this);
    }

    updateDetails=(e)=>{
        e.preventDefault();
        let details={ccontactNo: this.state.ccontactNo, cemailId: this.state.cemailId};
        console.log('details =>'+JSON.stringify(details));
        console.log('id => ' + JSON.stringify(this.state.cid));
        CollegeDetailsService.updateDetails(this.state.cid, details).then(res => {
            console.log(res);
        });
    this.props.history.push('/view_college_details');

       
    }

    viewRecruiters=(e)=>{
        this.props.history.push('/get_recruiter_list');
    }

    cancel(){
        this.props.history.push('/view_college_details');
    }

    changeContactNoHandler=(handle)=>{
        this.setState({
            ccontactNo:handle.target.value
        });
    }

    changeEmailIdHandler=(handle)=>{
        this.setState({
            cemailId:handle.target.value
        });
    }

    /*componentDidMount(){
        CollegeDetailsService.getDetailsById(this.state.cid).then((res)=>{
            let details=res.data;
            this.setState({
                ccontactNo: details.ccontactNo,
                cemailId: details.cemailId
            });
        });
    }*/

    render(){
        return(
        <div id="bg"><br/><br/><br/><br/>
            <div className="container">
                <div className="row">
                    <div id="in" className="card col-md-6 offset-md-3">
                        <h1 className="text-center">Update College Details</h1>
                            <div className="card-body">
                                <form>
                                    <div>
                                        <label>Contact Number: </label>
                                        <input placeholder="eg: 9357185003" name="ccontactNo" className="form-control" 
                                            value={this.state.ccontactNo} onChange={this.changeContactNoHandler}/>
                                    </div><br/>
                                    <div>
                                        <label>Email ID: </label>
                                        <input placeholder="eg: cellplacement@vivekswami.in" name="cemailId" 
                                            className="form-control" value={this.state.cemailId} 
                                            onChange={this.changeEmailIdHandler}/>
                                    </div><br/><br/>

                                    <button className="btn btn-primary" onClick={this.updateDetails}>Update</button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} 
                                        style={{marginLeft:"10px"}}>Cancel</button>
                                        <br/><br/>
                                        
                                </form>
                                    
                            </div>
                    </div>
                    
                        
                        <a id="anchor" href="" onClick={this.viewRecruiters}>Click here</a> 
                        <div id="rec_list">&nbsp;to see recruiter's list
                    </div>
                </div><br/><br/><br/><br/><br/>
            </div>
        </div>
        )
    }
}
export default UpdateCollegeDetailsComponent