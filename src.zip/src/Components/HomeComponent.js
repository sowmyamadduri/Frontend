import React from 'react'
import Background from '../images/home.png'
import {Link} from 'react-router-dom'

var sectionStyle={
    height: "580px",
    
    
    backgroundImage: `url(${Background})`,
    backgroundRepeat:"no-repeat"

};

function HomeComponent(){
    return(
        <div max>
            <section style={sectionStyle}/>
            
            <div>
      <footer  className="footer2" >
      <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
      </div>
            
        </div>
    )
}

export default HomeComponent