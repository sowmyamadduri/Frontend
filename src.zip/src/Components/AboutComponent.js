import React from 'react'

function AboutComponent() {
    return (
        <div >
            <h2>About US</h2>
            <div>
      <footer  className="footer2" >
      <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
      </div>
        </div>
    )
}

export default AboutComponent