import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Studentservice from '../Services/StudentService'
import "../style.css"
import students from "../images/students.png"
class ViewStudentsComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                students: []
        }
        
    }

    

    componentDidMount(){
        Studentservice.getStudent().then((res) => {
            this.setState({ students: res.data});
        });
    }

    

    render() {
        return (
            <div  style ={{background: `url(${students})`,height:'541px',width:'100%', backgroundRepeat:"no-repeat",backgroundSize:"cover"}}> 
            <div className="container">
               <div className="py-4">
                 <h2 className="text-center">Student List</h2>
                 <a  className="m" href="/recruitermenu" >Go back to menu</a>
        
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered" >

                            <thead>
                                <tr>
                                    <th> First Name</th>
                                    <th> Last Name</th>
                                    <th> HSC</th>
                                    <th> SSC</th>
                                    <th>BE</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.students.map(
                                    student => 
                                        <tr key = {student.id}>
                                             <td> { student.firstName} </td>   
                                             <td> {student.lastName}</td>
                                             <td> {student.hsc}</td>
                                             <td> {student.ssc}</td>
                                             <td> {student.degree}</td>
                                             
                                             {/* <td>
                                                 <button onClick={ () => this.editEmployee(employee.id)} className="btn btn-info">Edit </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteEmployee(employee.id)} className="btn btn-danger">Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewEmployee(employee.id)} className="btn btn-info">View </button>
                                             </td> */}
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
            </div>
            </div>
        )
    }
}

export default ViewStudentsComponent