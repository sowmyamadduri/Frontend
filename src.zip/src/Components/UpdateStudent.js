import React, { Component } from 'react'
import StudentService from '../Services/StudentService';

class UpdateStudent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            userId: this.props.match.params.userId,
            firstName: '',
      lastName: '',
      branch:'',
      dob:'',
      mobileNo:'',
      ssc:'',
      hsc:'',
      degree:'',
      email: '',
      password: '',
      passwordConfirmation: "",
     
        }
        
        this.handleChange = this.handleChange.bind(this);
        
        this.updateStudent = this.updateStudent.bind(this);
    }

    handleChange(e) {
        const { name, value } = e.target;
          this.setState({
          [name]: value
        });
    
        return;
      }

      


    componentDidMount(){
          StudentService.findById(this.state.userId).then( (res) =>{
            let student = res.data;
            this.setState({firstName: student.firstName, lastName: student.lastName, branch: student.branch, 
                dob: student.dob,mobileNo: student.mobileNo,ssc: student.ssc,hsc: student.hsc,
                degree: student.degree,email: student.email,userId: student.userId,password: student.password,
                passwordConfirmation: student.passwordConfirmation
            });
        });
    }

    updateStudent = (e) => {
        e.preventDefault();
        let student = {firstName: this.state.firstName, lastName: this.state.lastName, branch: this.state.branch, 
            dob: this.state.dob,mobileNo: this.state.mobileNo,ssc: this.state.ssc,hsc: this.state.hsc,
            degree: this.state.degree,email: this.state.email,userId: this.state.userId,password: this.state.password,
            passwordConfirmation: this.state.passwordConfirmation};
              console.log('student => ' + JSON.stringify(student));
              StudentService.updateStudentById(student,this.state.userId).then(response=>{
                console.log(response)
                this.props.history.push('/students');
              })
              .catch(error=>{
                console.log(error)
              })
    }
    
    

    cancel(){
        this.props.history.push('/students');
    }

    render() {
        return (
          <div>
            <div className="main" >
        
        
          <div style={{textAlign:"center"}}>
          <form onSubmit={this.updateStudent} >
          <h3 className="text-center">Update Your Details</h3>
          <hr></hr>
            <label>First Name: </label>
            <input
              type="text"
              placeholder="First Name"
              name="firstName"
            
              value={this.state.firstName}
              onChange={this.handleChange}
              
             
            />
           <label>Last Name: </label>
            <input
              type="text"
              placeholder="Last Name"
              name="lastName"
              value={this.state.lastName}
              onChange={this.handleChange}
             
              
            />
             <label>Branch: </label>
            <input
              type="text"
              placeholder="Branch"
              name="branch"
              value={this.state.branch}
            onChange={this.handleChange}
              
           
            />
           
           <label>DOB: </label>
            <input
              type="text"
              placeholder="Date of Birth"
              name="dob"
              value={this.state.dob}
              onChange={this.handleChange}
             
          
            />
            
            <label>Mobile No: </label>
            <input
              type="text"
              placeholder="Mobile No"
              name="mobileNo"
              value={this.state.mobileNo}
              onChange={this.handleChange}
             
              
            />
            
            <label>SSC: </label>
            <input
              type="text"
              placeholder="SSC Percentage"
              name="ssc"
              value={this.state.ssc}
              onChange={this.handleChange}
              
            />
            <label>HSC: </label>
            <input
              type="text"
              placeholder="HSC Percentage"
              name="hsc"
              value={this.state.hsc}
              onChange={this.handleChange}
             
            />
            <label>BE: </label>
            <input
              type="text"
              placeholder="Degree Percentage"
              name="degree"
              value={this.state.degree}
              onChange={this.handleChange}
              
              
            />
             <label>Email: </label>

            <input
              type="email"
              placeholder="Email Address"
              name="email"
              value={this.state.email}
              onChange={this.handleChange}
           
    
            />
            
            
            <label>BE: </label>
            <input
              type="text"
              placeholder="User Id"
              name="userId"
              value={this.state.userId}
              onChange={this.handleChange}
              
              
            />
        
        <label>Password: </label>
            <input
              type="password"
              placeholder="Password"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
             
            />
            
            <br/>
            
            <button className="btn btn-success" onClick={this.updateStudent}>Edit</button>
            <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>

          </form>
          </div>
    
      </div>
      </div>
      
      
      
    );
  }
}


export default UpdateStudent