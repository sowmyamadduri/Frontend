import React from "react";
import  axios from 'axios';
import { Link } from 'react-router-dom'
import "../style.css"
import bg1 from '../images/bg1.png'

const emailValidator = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const passwordValidator = /^(?=.\d)(?=.[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
const criteriaValidator=/^(100(\.0{1,2})?|[1-9]?\d(\.\d{1,2})?)$/;

class RecruiterRegister extends React.Component {
  constructor() {
    super();
    this.state = {
    
      username:"",
      mail: "",
      password: "",
      company:"",
      jobProfile:"",
      eligibilityCriteria:"",
      annualPackage: "",
      department:"",
      userNameError:"",
      emailAddressError: "",
      passwordError: "",
      companyError:"",
      jobProfileError:"",
      eligibiltyCriteriaError:"",
      annualPackageError:"",
      departmentError:"",

     
      isFormSubmitted: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.validateEmailAddress = this.validateEmailAddress.bind(this);
    this.validatePassword = this.validatePassword.bind(this);
    this.validateCompany=this.validateCompany.bind(this);
    this.validateUsername=this.validateUsername.bind(this);
    this.validateJobProfile=this.validateJobProfile.bind(this);
    this.validateCriteria=this.validateCriteria.bind(this);
    this.validateAnnualPackage=this.validateAnnualPackage.bind(this);
    this.validateDepartment=this.validateDepartment.bind(this);
    
    this.validateField = this.validateField.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;

    this.setState({
      [name]: value
    });

    return;
  }

  handleBlur(event) {
    const { name } = event.target;

    this.validateField(name);
    return;
  }

  handleSubmit(event) {
    event.preventDefault();
    console.log(this.state)
    console.log(this.state)
        axios
        .post('http://localhost:8080/api/v1/recruiter', this.state)
        .then(response =>{
          alert("Successfully Submitted")
            console.log(response)
        })
        .catch(error =>{
            console.log(error)
        })
  }

  validateField(name) {
    let isValid = false;

    if (name === "username") isValid = this.validateUsername();
    else if (name === "mail") isValid = this.validateEmailAddress();
    else if(name==="password") isValid=this.validatePassword();
    else if (name === "company") isValid = this.validateCompany();
    else if (name === "jobProfile") isValid = this.validateJobProfile();
    else if (name==="eligibilityCriteria") isValid =this.validateCriteria();
    else if (name==="annualPackage") isValid =this.validateAnnualPackage();
    else if (name==="department") isValid =this.validateDepartment();
   
    return isValid;
  }

  validateJobProfile() {
    let jobProfileError = "";
    const value = this.state.jobProfile;
    if (value.trim() === "") jobProfileError = "Job profile is required";

    this.setState({
      jobProfileError
    });
    return jobProfileError === "";
  }
  validateCompany() {
    let companyError = "";
    const value = this.state.company;
    if (value.trim() === "") companyError = "Company Name is required";

    this.setState({
      companyError
    });
    return companyError === "";
  }

  validateDepartment() {
    let departmentError = "";
    const value = this.state.departmentError;
    if (value.trim() === "") departmentError = "Department is required";

    this.setState({
      departmentError
    });
    return departmentError === "";
  }
  validateAnnualPackage() {
    let annualPackageError = "";
    const value = this.state.annualPackageError;
    if (value.trim() === "") annualPackageError = "Annual package is required";

    this.setState({
      annualPackageError
    });
    return annualPackageError === "";
  }
  validateUsername() {
    let userNameError = "";
    const value = this.state.username;
    if (value.trim() === "")userNameError = "User Name is required";

    this.setState({
      userNameError
    });
    return userNameError === "";
  }

  validateEmailAddress() {
    let emailAddressError = "";
    const value = this.state.mail;
    if (value.trim === "") emailAddressError = "Email Address is required";
    else if (!emailValidator.test(value))
      emailAddressError = "Email is not valid";

    this.setState({
      emailAddressError
    });
    return emailAddressError === "";
  }
  
  validateCriteria() {
    let eligibiltyCriteriaError = "";
    const value = this.state.eligibilityCriteria;
    if (value.trim === "") eligibiltyCriteriaError = "Eligibilty criteria is required";
    else if (!criteriaValidator.test(value))
      eligibiltyCriteriaError = "Eligibilty criteria should be in percentage ";

    this.setState({
      eligibiltyCriteriaError
    });
    return eligibiltyCriteriaError === "";
  }
  validatePassword() {
    let passwordError = "";
    const value = this.state.password;
    if (value.trim === "") passwordError = "Password is required";
    else if (!passwordValidator.test(value))
      passwordError =
        "Password must contain at least 8 characters, 1 number, 1 upper and 1 lowercase!";

    this.setState({
      passwordError
    });
    return passwordError === "";
  }

  

  render() {
    return (
      <div  style ={{background: `url(${bg1})`,height:'770px',width:'100%', backgroundRepeat:"no-repeat",backgroundSize:"cover"}}> 
     
      <div className="main" >
        
        {/* {this.state.isFormSubmitted ? (
          <div className="details">
            <h3>Thanks for signing up, find your details below:</h3>
            <div>First Name: {this.state.firstName}</div>
            <div>Last Name: {this.state.lastName}</div>
            <div>Email Address: {this.state.emailAddress}</div>
          </div>
        ) : ( */}
          <div style={{textAlign:"center"}}>
          <form onSubmit={this.handleSubmit} >
          <h4 textAlign="center"  class="label1 text-primary">Registration Form</h4>
          <hr></hr>
            <label  class="label1 text-primary">User Name:</label>
            <input
              type="text"
              placeholder="User Name"
              name="username"
              value={this.state.username}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.userNameError && (
              <div className="errorMsg">{this.state.userNameError}</div>
            )}
            
            <label class="label1 text-primary">Email Id: </label>
            <input
              type="email"
              placeholder="Email Address"
              name="mail"
              value={this.state.mail}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.emailAddressError && (
              <div className="errorMsg">{this.state.emailAddressError}</div>
            )}
            <label  class="label1 text-primary">Password:</label>
            <input
              type="password"
              placeholder="Password"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.passwordError && (
              <div className="errorMsg">{this.state.passwordError}</div>
            )}
            <label  class="label1 text-primary">Company:</label>
            <input
              type="text"
              placeholder="Company Name"
              name="company"
              value={this.state.company}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.companyError && (
              <div className="errorMsg">{this.state.companyError}</div>
            )}

            <label class="label1 text-primary">Job Profile:</label>
            <input
              type="text"
              placeholder="Job Profile"
              name="jobProfile"
              value={this.state.jobProfile}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.jobProfileError && (
              <div className="errorMsg">{this.state.jobProfileError}</div>
            )}
            <label  class="label1 text-primary">Eligibilty Criteria:</label>
            <input
              type="text"
              placeholder="Eligibility Criteria"
              name="eligibilityCriteria"
              value={this.state.eligibilityCriteria}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.eligibiltyCriteriaError && (
              <div className="errorMsg">{this.state.eligibiltyCriteriaError}</div>
            )}
            <label  class="label1 text-primary">Annual Package:</label>
            <input
              type="text"
              placeholder=" Annual package"
              name="annualPackage"
              value={this.state.annualPackage}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.annualPackageError && (
              <div className="errorMsg">{this.state.annualPackageError}</div>
            )}
            <label  class="label1 text-primary">Department:</label>
            <input
              type="text"
              placeholder="Department"
              name="department"
              value={this.state.department}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            <br />
            {this.state.departmentError && (
              <div className="errorMsg">{this.state.departmentError}</div>
            )}
            
            <div>
            <button class="btn btn-outline-primary"onClick={this.handleSubmit}>Signup</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <Link class="loginlink" to="/recruiterlogin">Go to Login</Link>
             </div>
           
            
          </form>
          </div>
        
      </div>
      <div>
      <footer  className="footer1" >
      <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
      </div>
      </div>
      
    );
  }
}
export default RecruiterRegister;