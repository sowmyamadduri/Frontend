import axios from 'axios';
import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.css'
import "../style.css"
import bg1 from "../images/bg1.png"




class RecruiterLogin extends Component {
    constructor(props) {
        super(props)
        this.state = {
            mail: '',
            password: '',





        };
    }

    onChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    handleSubmit = (event) => {
        event.preventDefault()
        console.log(this.state)
        axios
            .post('http://localhost:8080/api/v1/recruiters/login', this.state)

            .then(
                response => {
                    alert(`Login Successful`)
                    this.props.history.push('/recruitermenu')
                })
            .catch(
                error => {
                    alert(`Login failed!!! worng credentials`)
                })
        this.setState({ mail: '', password: '' })
    }



    validateField(name) {
        let isValid = false;

        if (name === "mail") isValid = this.validateMail();
        else if (name === "password") isValid = this.validatePassword();

        return isValid;
    }


    render() {
        return (

            <div  style ={{background: `url(${bg1})`,height:'541px',width:'100%', backgroundRepeat:"no-repeat",backgroundSize:"cover"}}> 
                <div className="main" >

                    <div style={{ textAlign: "center" }}>
                        <form method="POST" onSubmit={this.handleSubmit}>
                            <div>
                                <h4 textAlign="center" className="text-primary">Login Form</h4>
                                <hr></hr>
                                <label  class="label1 text-primary">Email Id: </label>
                                <input
                                    type="text"
                                    placeholder="Email Id"
                                    name="mail"
                                    value={this.state.mail}
                                    onChange={this.onChange}
                                    //onBlur={this.handleBlur}
                                    autoComplete="off"
                                />
                            </div>
                            <div>
                                <br />
                                <label  class="label1 text-primary">Password: </label>

                                <input 
                                    type="password"
                                    placeholder="Password"
                                    name="password"
                                    value={this.state.password}
                                    onChange={this.onChange}
                                    //onBlur={this.handleBlur}
                                    autoComplete="off"
                                />
                            </div>
                            <div>
                             <br/>
                                <button type="submit" class="btn  btn-outline-primary" >Login</button> 
                                <div>
                                <hr/>
                                <small textAlign="center"> Don't have an account? <Link class="text-info" to="/recruiterRegister">Register</Link></small><br/>
                                <small textAlign="center"> Forgot Password? <Link class="text-info" to="/recruiterpassword">Change Password</Link></small></div>
                                </div>
                        </form>

                    </div>

                </div>
                <div>
                    <footer className="footer2" >
                        <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
                </div>

            </div>


        );
    }
}

export default RecruiterLogin;