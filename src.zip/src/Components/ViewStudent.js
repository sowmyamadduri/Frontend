import React, { Component } from 'react'
import StudentService from '../Services/StudentService'
import { Link } from 'react-router-dom'
import "../studentstyle.css"
class ViewStudent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            userId: this.props.match.params.userId,
            student: {}
        }
    }

    componentDidMount() {
        StudentService.findById(this.state.userId).then(res => {
            this.setState({ student: res.data });
        })
    }

    render() {
        return (
            <div>
                <div>
                    <br></br>
                    <div>
                        <div className="container"><br />
                            <div className="row">
                                <div className="card col-md-6 offset-md-3"><br />
                                    <h3 className="text-center">Student Details</h3>
                                    
                    <br/><hr/>
                    <h1 className="display-8">User Id: {this.state.student.userId}</h1>
                    


                                    <div className="card-body">
                                        <div className="text-left">
                                            <table>
                                                <tr>
                                                    <td>First Name:</td>

                                                    <td >{this.state.student.firstName}</td>
                                            </tr><br />

                                                <tr>
                                                    <td>Last Name:</td>

                                                    <td >{this.state.student.lastName}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>Branch:</td>

                                                    <td >{this.state.student.branch}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>DOB:</td>

                                                    <td >{this.state.student.dob}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>Mobile No:</td>

                                                    <td >{this.state.student.mobileNo}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>SSC:</td>

                                                    <td >{this.state.student.ssc}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>HSC:</td>

                                                    <td >{this.state.student.hsc}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>BE:</td>

                                                    <td >{this.state.student.degree}</td>
                                            </tr><br />
                                                <tr>
                                                    <td>Email:</td>

                                                    <td >{this.state.student.email}</td>
                                            </tr><br />
                                            <Link style={{marginLeft: "10px"}} className="btn btn-primary" to="/students">
                        Back
                    </Link>


                                            </table>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewStudent