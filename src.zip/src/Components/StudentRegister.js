import React, { Component } from "react";
import StudentService from '../Services/StudentService'
import "../studentstyle.css"
//import Background from '../images/reg1.png'
const emailValidator = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//const passwordValidator = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
const mobileValidator=/^[0-9\b]+$/;


export class StudentRegister extends Component {
  constructor() {
    super();
    this.state = {
      firstName: "",
      lastName: "",
      branch:"",
      dob:"",
      mobileNo:"",
      ssc:"",
      hsc:"",
      degree:"",
      email: "",
      userId:"",
      password: "",
      passwordConfirmation: "",
      firstNameError: "",
      branchError:"",
      dobError:"",
      mobileNoError:"",
      sscError:"",
      hscError:"",
      degreeError:"",
      emailError: "",
      userIdError:"",
      passwordError: "",
      passwordConfirmationError: "",
      isFormSubmitted: false
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleBlur = this.handleBlur.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.validateFirstName = this.validateFirstName.bind(this);
    this.validateLastName = this.validateLastName.bind(this);
    this.validateBranch = this.validateBranch.bind(this);
    this.validateDob = this.validateDob.bind(this);
    this.validateMobileNo = this.validateMobileNo.bind(this);
    this.validateSsc = this.validateSsc.bind(this);
    this.validateHsc = this.validateHsc.bind(this);
    this.validateDegree = this.validateDegree.bind(this);
    this.validateEmail = this.validateEmail.bind(this);
    this.validateUserId = this.validateUserId.bind(this);
    this.validatePassword = this.validatePassword.bind(this);
    this.validatePasswordConfirmation = this.validatePasswordConfirmation.bind(
      this
    );
    this.validateField = this.validateField.bind(this);
  }

  handleChange(event) {
    const { name, value } = event.target;
      this.setState({
      [name]: value
    });

    return;
  }

  handleBlur(event) {
    const { name } = event.target;

    this.validateField(name);
    return;
  }

  handleSubmit(event) {
    
    event.preventDefault();
   
    let student = {firstName: this.state.firstName, lastName: this.state.lastName, branch: this.state.branch, 
      dob: this.state.dob,mobileNo: this.state.mobileNo,ssc: this.state.ssc,hsc: this.state.hsc,
      degree: this.state.degree,email: this.state.email,userId: this.state.userId,password: this.state.password,
      passwordConfirmation: this.state.passwordConfirmation};
      alert(`Okay ${this.state.email} Thanks for Registrations!!!`)
        console.log('student => ' + JSON.stringify(student));
        StudentService.save(student).then(res => {
          console.log(res)
         
          this.props.history.push('/studentlogin');
        });
      
    let formFields = [
      "firstName",
      "lastName",
      "branch",
      "dob",
      "mobileNo",
      "ssc",
      "hsc",
      "degree",
      "email",
      "userId",
      "password",
      "passwordConfirmation"
    ];
    let isValid = true;
    formFields.forEach(field => {
      isValid = this.validateField(field) && isValid;
    });

    if (isValid) this.setState({ isFormSubmitted: true });
    else this.setState({ isFormSubmitted: false });

    return this.state.isFormSubmitted;
   
  }

  validateField(name) {
    let isValid = false;

    if (name === "firstName") isValid = this.validateFirstName();
    else if (name === "lastName") isValid = this.validateLastName();
    else if (name === "branch") isValid = this.validateBranch();
    else if (name === "dob") isValid = this.validateDob();
    else if (name === "mobileNo") isValid = this.validateMobileNo();
    else if (name === "ssc") isValid = this.validateSsc();
    else if (name === "hsc") isValid = this.validateHsc();
    else if (name === "degree") isValid = this.validateLastName();
    else if (name === "email") isValid = this.validateEmail();
    else if (name === "userId") isValid = this.validateUserId();
    else if (name === "password") isValid = this.validatePassword();
    else if (name === "passwordConfirmation")
      isValid = this.validatePasswordConfirmation();
    return isValid;
  }

  validateFirstName() {
    let firstNameError = "";
    const value = this.state.firstName;
    if (value.trim() === "") firstNameError = "First Name is required";

    this.setState({
      firstNameError
    });
    return firstNameError === "";
  }

  validateLastName() {
    let lastNameError = "";
    const value = this.state.lastName;
    if (value.trim() === "") lastNameError = "Last Name is required";

    this.setState({
      lastNameError
    });
    return lastNameError === "";
  }
  validateBranch() {
    let branchError = "";
    const value = this.state.branch;
    if (value.trim() === "") branchError = "Branch is required";

    this.setState({
      branchError
    });
    return branchError === "";
  }
  validateDob() {
    let dobError = "";
    const value = this.state.dob;
    if (value.trim() === "") dobError = "Date of Birth is required";

    this.setState({
      dobError
    });
    return dobError === "";
  }
  validateMobileNo() {
    let mobileNoError = "";
    const value = this.state.mobileNo;
    if (value.trim() === "") mobileNoError = "Mobile No is required";
    else if (!mobileValidator.test(value))
      mobileNoError = "Mobile No is not valid";

    this.setState({
      mobileNoError
    });
    return mobileNoError === "";
  }
  validateSsc() {
    let sscError = "";
    const value = this.state.ssc;
    if (value.trim() === "") sscError = "SSC Percentage is required";

    this.setState({
      sscError
    });
    return sscError === "";
  }
  validateHsc() {
    let hscError = "";
    const value = this.state.hsc;
    if (value.trim() === "") hscError = "HSC Percentage is required";

    this.setState({
      hscError
    });
    return hscError === "";
  }
  validateDegree() {
    let degreeError = "";
    const value = this.state.degree;
    if (value.trim() === "") degreeError = "Degree Percentage is required";

    this.setState({
      degreeError
    });
    return degreeError === "";
  }

  validateEmail() {
    let emailError = "";
    const value = this.state.email;
    if (value.trim === "") emailError = "Email Address is required";
    else if (!emailValidator.test(value))
      emailError = "Email is not valid";

    this.setState({
      emailError
    });
    return emailError === "";
  }

  validateUserId() {
    let userIdError = "";
    const value = this.state.userId;
    if (value.trim() === "") userIdError = "User Id is required";

    this.setState({
      userIdError
    });
    return userIdError === "";
  }

  validatePassword() {
    let passwordError = "";
    const value = this.state.password;
    if (value.trim === "") passwordError = "Password is required";
   /* else if (!passwordValidator.test(value))
      passwordError =
        "Password must contain at least 8 characters, 1 number, 1 upper and 1 lowercase!";*/

    this.setState({
      passwordError
    });
    return passwordError === "";
  }

  validatePasswordConfirmation() {
    let passwordConfirmationError = "";
    if (this.state.password !== this.state.passwordConfirmation)
      passwordConfirmationError = "Password does not match Confirmation";

    this.setState({
      passwordConfirmationError
    });
    return passwordConfirmationError === "";
  }
  cancel(){
    this.props.history.push('/login');
}

  

render() {
  return (

      <div>
     
    <div className="main" >
      
      {/* {this.state.isFormSubmitted ? (
        <div className="details">
          <h3>Thanks for signing up, find your details below:</h3>
          <div>First Name: {this.state.firstName}</div>
          <div>Last Name: {this.state.lastName}</div>
          <div>Email Address: {this.state.emailAddress}</div>
        </div>
      ) : ( */}
        <div style={{textAlign:"center"}}>
        <form onSubmit={this.handleSubmit} >
        <h3 textAlign="center"><b>Registration Form</b></h3>
        <hr></hr>
          <label>First Name: </label>
          <input
            type="text"
            placeholder="First Name"
            name="firstName"
            value={this.state.firstName}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
            <br />
            {this.state.firstNameError && (
              <div className="errorMsg">{this.state.firstNameError}</div>
            )}
          <label>Last Name: </label>
          <input
            type="text"
            placeholder="Last Name"
            name="lastName"
            value={this.state.lastName}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.lastNameError && (
            <div className="errorMsg">{this.state.lastNameError}</div>
          )}
           <label>Branch: </label>
          <input
            type="text"
            placeholder="Branch"
            name="branch"
            value={this.state.branch}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.branchError && (
            <div className="errorMsg">{this.state.branchError}</div>
          )}
          
           <label>DOB: </label>

          <input
            type="text"
            placeholder="Date of Birth"
            name="dob"
            value={this.state.dob}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.dobError && (
            <div className="errorMsg">{this.state.dobError}</div>
          )}
          
          <label>Mobile No: </label>
          <input
            type="text"
            placeholder="Mobile No"
            name="mobileNo"
            value={this.state.mobileNo}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
         <br />
          {this.state.mobileNoError && (
            <div className="errorMsg">{this.state.mobileNoError}</div>
          )}
           <label>SSC: </label>
          <input
            type="text"
            placeholder="SSC Percentage"
            name="ssc"
            value={this.state.ssc}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.sscError && (
            <div className="errorMsg">{this.state.sscError}</div>
          )}
           
           <label>HSC: </label>

          <input
            type="text"
            placeholder="HSC Percentage"
            name="hsc"
            value={this.state.hsc}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.hscError && (
            <div className="errorMsg">{this.state.hscError}</div>
          )}
           
           <label>Degree: </label>
          <input
            type="text"
            placeholder="Degree Percentage"
            name="degree"
            value={this.state.degree}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
       <br />
          {this.state.degreeError && (
            <div className="errorMsg">{this.state.degreeError}</div>
          )}
           
           <label>Email: </label>
          <input
            type="email"
            placeholder="Email Address"
            name="email"
            value={this.state.email}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
         <br />
          {this.state.emailError && (
            <div className="errorMsg">{this.state.emailError}</div>
          )}
         

         <label>User Id: </label>
          <input
            type="text"
            placeholder="User Id"
            name="userId"
            
            value={this.state.userId}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
         <br />
          {this.state.userIdError && (
            <div className="errorMsg">{this.state.userIdError}</div>
          )}
           
           <label>Password: </label> 
          <input
            type="password"
            placeholder="Password"
            name="password"
            
            value={this.state.password}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
         <br />
          {this.state.passwordError && (
            <div className="errorMsg">{this.state.passwordError}</div>
          )}
           
           <label>Confirm Password: </label> 
          <input
            type="password"
            placeholder="Confirm Password"
            name="passwordConfirmation"
            value={this.state.passwordConfirmation}
            onChange={this.handleChange}
            onBlur={this.handleBlur}
            autoComplete="off"
          />
          <br />
          {this.state.passwordConfirmationError && (
            <div className="errorMsg">
              {this.state.passwordConfirmationError}
            </div>
          )}
           
           <div>
          <button className="btn btn-success" >Sign Up</button>
          <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
           </div>
        </form>
        </div>
      
   
        </div>
      <div>
      <footer  className="footer1" >
      <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
      </div>
      </div>
    
    
  );
}
}


export default StudentRegister;



