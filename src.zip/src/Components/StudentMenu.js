import React, { Component }from 'react'
import StudentService from '../Services/StudentService'
import 'bootstrap/dist/css/bootstrap.css'
import { BrowserRouter as Router, Route, Link, Switch, NavLink } from 'react-router-dom';
import ListAllStudents from './ListAllStudents';
import student from "../images/student.png"
import reg from "../images/reg.png"
class StudentMenu extends Component{
  constructor(props) {
    super(props)

    this.state = {
        userId: this.props.match.params.userId,
       student: {}
    }
}
  componentDidMount(){
    StudentService.getStudent().then((res) => {
        this.setState({ student: res.data});
    });
}

    render() {
        return (
          <div  style ={{background: `url(${reg})`,height:'700px',width:'100%', backgroundRepeat:"no-repeat",backgroundSize:"cover"}}>
      <div >
      <Router>
        
      <div class="container">  
             <div class="row">

             <div class="col-md-2 col-md-offset-1" class="image1">
             <img src={student} alt="student" />
             <div>
             
              <a className="sa" href="/students" > List Of Students</a>
              </div>
              </div>
              </div>
             </div> 
             
             
       <Switch>

         
         <Route path='/students' exact component={ListAllStudents} />
         
       </Switch>
       
      </Router>
    </div>
    </div>
    );
}
}
export default StudentMenu