import axios from 'axios';
import React, { Component } from 'react';


class ViewRecruiterDetails extends Component {
    constructor(props) {
        super(props)
        this.state = {
            mail: '',
            recruiters: [],
            url: 'http://localhost:8080/api/v1/recruiters/',
            a: ''
        }
    }
    handleSubmit = (e) => {
        e.preventDefault()
        let a = this.state.mail
        console.log(a)
        axios
            .get((this.state.url) + `${a}`)
            .then(response => {
                console.log(response.data)
                this.setState({
                    recruiters: response.data
                })
            })
            .catch(error => {
                console.log(error)
            })
    }
    editDetails(id) {
        this.props.history.push(`/update/${id}`);
    }
    onChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });

    }
    render() {
        return (
            <div>
                <div>
                <a  className="m" href="/recruitermenu" >Go back to menu</a>
                    <div className="container-xl">
                        <div className="row ">
                            <div className="card col-md-6 offset-md-3">
                                <div className="card-body">
                                    <h5 className="a text-center " >View Details </h5> <hr />
                                    <form onSubmit={this.handleSubmit} className="row g-3">
                                    <div className="col">
                                            <input value={this.state.mail} name="mail" placeholder="enter email address  "
                                                className="form-control" onChange={this.onChange} /> 
                                                
                                                 <div className="col"></div>
                                                &nbsp;&nbsp;
                                            <button className="btn btn-outline-primary">Confrim</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <form className="row g-3">
                    <div className="col-auto">
                        <label for="staticEmail2" className="visually-hidden">Email</label>
                        <input type="text" readonly className="form-control-plaintext" id="staticEmail2" value="email@example.com">
  </div>
                        <div className="col-auto">
                            <label for="inputPassword2" className="visually-hidden">Password</label>
                            <input type="password" className="form-control" id="inputPassword2" placeholder="Password">
  </div>
                            <div classNames="col-auto">
                                <button type="submit" className="btn btn-primary mb-3">Confirm identity</button>
                            </div>
</form>
                <div className="my-5" >
                    <table className="table table-striped table-bordered ">
                        <thead >
                            <tr>
                                <th>Id</th>
                                <th>firstname</th>
                                <th>lastname</th>
                                <th>username</th>
                                <th>password</th>
                                <th>mail</th>
                                <th>company</th>
                                <th>actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.recruiters.map(
                                    recruiter =>
                                        <tr key={recruiter.id} >
                                            <td>{recruiter.id}</td>
                                            <td>{recruiter.firstname}</td>
                                            <td>{recruiter.lastname}</td>
                                            <td>{recruiter.username}</td>
                                            <td>{recruiter.password}</td>
                                            <td>{recruiter.mail}</td>
                                            <td>{recruiter.company}</td>
                                            <td>
                                                <button className="btn btn-info">Update</button>
                                            </td>
                                     </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div> */}
                <div>
                    <div className="container"><br />
                        <div className="row">
                            <div className="card col-md-6 offset-md-3"><br />
                                <h4 className="text-center"  >Recruiter Details</h4>
                                <hr></hr>

                                <div className="card-body">
                                    <div className="text-left" className="text-primary">
                                        <table>
                                            <tr>
                                                <td>Recruiter ID:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.id}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>Recruiter Name:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.username}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>Recruiter mail:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.mail}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>Recruiter company:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.company}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>Recruiter Name:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.jobProfile}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>RecruiterCriteria:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.eligibilityCriteria}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>RecruiterPackage:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.annualPackage}</td>)}
                                            </tr><br />

                                            <tr>
                                                <td>Recruiter Department:</td>
                                                {this.state.recruiters.map(
                                                    recruiter =>
                                                        <td key={recruiter.id}>{recruiter.department}</td>)}
                                            </tr><br />
                                        </table>
                                    </div>
                                    {
                                        this.state.recruiters.map(
                                            recruiter =>
                                                <div key={recruiter.id}>
                                                    <button onClick={() => this.editDetails(recruiter.id)}
                                                        className="btn btn-primary">Update</button>
                                                </div>
                                        )
                                    }

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ViewRecruiterDetails;