import React, { Component } from 'react';
import axios from 'axios'
import RecruiterService from '../Services/RecruiterService';

class UpdateRecruiter extends Component {
    constructor(props) {
        super(props)
        this.state = {
            id:this.props.match.params.id,
           
            password: '',
            mail:'',
    
            jobProfile: '',
            eligibilityCriteria: '',
            annualPackage: '',
            department : ''
        }
    }
    //handling changes 
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    submitHandler = (event) => {
        // alert(`${this.state.username} ${this.state.password} ${this.state.mail} ${this.state.company} `)
        let recruiter = {
            password: this.state.password,
            mail:this.state.mail,
           
            jobProfile: this.state.jobProfile,
            eligibilityCriteria: this.state.eligibilityCriteria,
            annualPackage: this.state.annualPackage,
            department : this.state.department };
        console.log('recruiter => ' + JSON.stringify(recruiter));
        event.preventDefault()
        RecruiterService.updateRecruiter(recruiter,this.state.id)
            .then(response => {
                console.log(response)
            })
            .catch(error => {
                console.log(error)
            })
            this.props.history.push(`/`)
        }
        // home(){
        //     this.props.history.push(`/`);
        // }
fetch(){
    this.props.history.push(`/`)
}
    render() {
        return (
            <div>
     
      <div className="main" >
        
       
          <div style={{textAlign:"center"}}>
          <form onSubmit={this.submitHandler} >
          <h4 textAlign="center">Update Your Details</h4>
          <hr></hr>
            
            
            <label>Email Id: </label>
            <input
              type="email"
              placeholder="Email Address"
              name="mail"
              value={this.state.mail}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            
            <label>Password:</label>
            <input
              type="password"
              placeholder="Password"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
           

            <label>Job Profile:</label>
            <input
              type="text"
              placeholder="Job Profile"
              name="jobProfile"
              value={this.state.jobProfile}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
           
            <label>Eligibilty Criteria:</label>
            <input
              type="text"
              placeholder="Eligibility Criteria"
              name="eligibilityCriteria"
              value={this.state.eligibilityCriteria}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            
            <label>Annual Package:</label>
            <input
              type="text"
              placeholder=" Annual package"
              name="annualPackage"
              value={this.state.annualPackage}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
          
            <label>Department:</label>
            <input
              type="text"
              placeholder="Department"
              name="department"
              value={this.state.department}
              onChange={this.handleChange}
              onBlur={this.handleBlur}
              autoComplete="off"
            />
            
            <div>
            <button class="btn btn-success"onClick={this.submitHandler}>Update</button>
             
             </div>
           
            
          </form>
          </div>
        
      </div>
      <div>
      <footer  className="footer1" >
      <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
      </div>
      </div>
        );
    }
}
export default UpdateRecruiter;