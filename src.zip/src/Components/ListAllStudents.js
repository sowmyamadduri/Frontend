import React, { Component } from 'react'
import StudentService from '../Services/StudentService.js'

class ListAllStudents extends Component {
    constructor(props) {
        super(props)

        this.state = {
                student: []
        }
        this.updateStudent = this.updateStudent.bind(this);
    }
    viewStudent(userId){
        this.props.history.push(`/view-student/${userId}`);
    }

    updateStudent(userId){
        this.props.history.push(`/update-student/${userId}`);
    }

    
    componentDidMount(){
        StudentService.getStudent().then((res) => {
            this.setState({ student: res.data});
        });
    }

    

    render() {
        return (
            <div className="container">
                <div className="py-4">
                 <h2 className="text-center">Students List</h2>
                 
                 <br></br>
                 
                        <table class="table border shadow">

                            <thead class="thead-dark">
                                <tr>
    
                                    <th> First Name</th>
                                    <th> Last Name</th>
                                    <th> Branch</th>
                                    <th> Mobile Number </th>
                                    <th> Email</th>
                                    <th> BE</th>
                                    <th> Actions</th>
                
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.student.map(
                                    student => 
                                        <tr key = {student.userId}>
                                             <td> {student.firstName} </td>   
                                             <td> {student.lastName}</td>
                                             <td> {student.branch}</td>
                                             <td> {student.mobileNo}</td>
                                             <td> {student.email}</td>
                                             <td> {student.degree}</td>
                                             <td>
                                             
                                             
                                             <button style={{marginLeft: "10px"}} onClick={ () => this.viewStudent(student.userId)} className="btn btn-primary mr-2">View </button>
                                             <button onClick={ () => this.updateStudent(student.userId)} className="btn btn-outline-primary mr-2">Edit </button>
  
                                             </td>
                                        </tr>

                                    )
                                }
                            </tbody>
                        </table>
                        </div>
                        

                 </div>

            
        )
    }
}

export default ListAllStudents