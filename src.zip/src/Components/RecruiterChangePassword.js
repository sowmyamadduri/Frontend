import React, { Component } from 'react';
import axios from 'axios'
import { Link } from 'react-router-dom'
import bg1 from '../images/bg1.png'

class RecruiterChangePassword extends Component {
    constructor(props) {
        super(props)
        this.state = {
            id: '',
            Password:'',
            url: 'http://localhost:8080/api/v1/recruiters/',
            a: ''
        }
    }
    onChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }
    submitHandler = (e) => {
        // alert(`${this.state.username} ${this.state.password} ${this.state.mail} ${this.state.company} `)
        // let recruiter = { firstname: this.state.firstname,
        // lastname: this.state.lastname,
        // username: this.state.username,
        // password: this.state.password,
        // mail: this.state.mail,
        // company: this.state.company };
        e.preventDefault()
        let a = this.state.id
        console.log(a)
        let recruiter = { 
            password: this.state.password};
        console.log('recruiter => ' + JSON.stringify(recruiter));
            axios.patch((this.state.url + a),recruiter)
            .then(response => {
                console.log(response.data)
            })
            .catch(error => {
                console.log(error)
            })
            this.props.history.push(`/recruiterlogin`)
        }
       
    render() {
        return (
           
            <div  style ={{background: `url(${bg1})`,height:'541px',width:'100%', backgroundRepeat:"no-repeat",backgroundSize:"cover"}}>
                <div className="main" >

                    <div style={{ textAlign: "center" }}>
                        <form method="POST" onSubmit={this.submitHandler}>
                            <div>
                                <h4 textAlign="center" className="text-primary">Login Form</h4>
                                <hr></hr>
                                <label  class="label1 text-primary">Recruiter Id: </label>
                                <input
                                    type="text"
                                    placeholder="Enter your Id"
                                    name="id"
                                    value={this.state.id}
                                    onChange={this.onChange}
                                    //onBlur={this.handleBlur}
                                    autoComplete="off"
                                />
                            </div>
                            <div>
                                <br />
                                <label  class="label1 text-primary">Password: </label>

                                <input 
                                    type="password"
                                    placeholder="Password"
                                    name="password"
                                    value={this.state.password}
                                    onChange={this.onChange}
                                    //onBlur={this.handleBlur}
                                    autoComplete="off"
                                />
                            </div>
                            <div>
               <button class="btn btn-outline-primary">Update</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <Link class="loginlink" to="/recruiterlogin">Go to Login</Link>
             </div>
                        </form>

                    </div>

                </div>
                <div>
                    <footer className="footer2" >
                        <spam className="text-muted">Copyright &copy; 2021. All rights reserved.</spam></footer>
                </div>

            </div>

        );
    }
}
export default RecruiterChangePassword;