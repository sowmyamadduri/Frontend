 
import React from 'react';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as IoIcons from 'react-icons/io';
import * as MdIcons from 'react-icons/md'
import * as GrIcons from 'react-icons/gr'
export const RecruiterMenuData = [
  {
    title: 'Home',
    path: '/',
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: 'View Students',
    path: '/viewStudents',
    icon:<MdIcons.MdViewList/>,
    cName: 'nav-text'
  },
  {
    title: 'View Details',
    path: 'ViewRecruiterDetails',
    icon: <FaIcons.FaStreetView/>,
    cName: 'nav-text'
  },
  {
    title: 'Mail',
    path: '/sendMail',
    icon: <GrIcons.GrMail/>,
    cName: 'nav-text'
  },
  
];

