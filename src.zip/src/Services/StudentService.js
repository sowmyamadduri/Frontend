import axios from 'axios';

const STUDENT_API_BASE_URL = "http://localhost:8080/api/v1/students";

class StudentService {

    getStudent(){
        return axios.get(STUDENT_API_BASE_URL);
    }


    save(student){
        return axios.post(STUDENT_API_BASE_URL, student);
    }

    
    findById(userId){
        return axios.get(STUDENT_API_BASE_URL + '/' + userId);
    }


    updateStudentById(student, userId){
        return axios.put(STUDENT_API_BASE_URL + '/' + userId, student);
    }


    

   
}

export default new StudentService()