import axios from 'axios'

const BASE_URL = "http://localhost:8080/api/v1/recruiters"
class RecruiterService {
    createRecruiter(recruiter) {
        return axios.post(BASE_URL,recruiter);
    }
    getRecruiter(mail){
        return axios.get(BASE_URL + '/' + mail)
     }
     updateRecruiter(recruiter, id) {
        return axios.patch(BASE_URL + '/' + id, recruiter)
     }
     login(recruiter) {
         return axios.post(BASE_URL + '/login')
     }
}
export default new RecruiterService()